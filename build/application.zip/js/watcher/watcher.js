/**
 * Created by 01 Alchemist on 19/8/2015.
 */

window.RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection ||
    window.webkitRTCPeerConnection || window.msRTCPeerConnection;
window.RTCSessionDescription = window.RTCSessionDescription || window.mozRTCSessionDescription ||
    window.webkitRTCSessionDescription || window.msRTCSessionDescription;

window.Watcher = function () {

    var video,video2;
    var _stream;
    var _servers={

    };
    var _connection;
    var _connection2;

    return {
        start: function () {
            console.log('starting...');
            var scope = this;
            window.camera.getVideoCamera('front').then(function (cam) {
                console.log('got camera:',cam);
                _stream = cam; //camera is s MediaStream
                video = document.getElementById('video1');
                video2 = document.getElementById('video2');
                console.log('got both videos');
                video.mozSrcObject = cam;
                video.play();
                console.log('will connect');
                scope.connect();
            })
        },
        connect:function(){
            console.log('connecting...');
            var scope = this;
            var loc_desc;
            try {
                _connection = new RTCPeerConnection(_servers);
                _connection.addStream(_stream);
                console.log('connection1 created');

                _connection2 = new RTCPeerConnection(_servers);
                console.log('connection2 created');
                _connection2.onaddstream = function (event) {
                    console.log('got remote stream');
                    video2.mozSrcObject = URL.createObjectURL(e.stream);
                    video2.play();
                };

                //create offer
                _connection.createOffer(function(offer) {
                    console.log('offer created');
                    loc_desc = new RTCSessionDescription(offer);
                    _connection.setLocalDescription(loc_desc, function() {
                        // send the offer to a server to be forwarded to the friend you're calling.
                        console.log('offer sent to server');
                        scope.onRemoteOffer(offer);
                    }, scope.error);

                }, scope.error);

            }catch(e){
                console.log(e);
            }
        },
        onRemoteOffer:function(offer){
            console.log('got offer');
            //console.log("Offer from connection1 \n" + desc.sdp);
            _connection2.setRemoteDescription(new RTCSessionDescription(offer),function() {
                console.log('connection2 remote desc set');
                _connection2.createAnswer(function (answer) {
                    console.log('answer created');
                    _connection2.setLocalDescription(new RTCSessionDescription(answer), function () {
                        // send the answer to a server to be forwarded back to the caller (you)
                        console.log('answer sent to server');
                        scope.onRemoteAnswer(answer);
                    }, error);
                }, error);
            });
        },
        onRemoteAnswer:function(answer){
            console.log('got answer');
            //console.log("Offer from connection2 \n" + desc.sdp);
            _connection.setRemoteDescription(new RTCSessionDescription(answer), function(){
                console.log('all done!');
            });
        },
        stop: function () {
            window.camera.releaseCamera();
        },
        error:function(e){
            console.error(e);
        }
    }
};
var _watcher = new Watcher();
window.addEventListener('WIFI_READY',function(e) {
    console.log('///////////////////////////////\n' +
                '// Broadcast started...      //\n' +
                '///////////////////////////////');
    _watcher.start();
});

//navigator.mozPower.screenEnabled = false;
console.log('Watcher ready');